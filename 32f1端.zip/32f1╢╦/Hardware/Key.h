#ifndef __KEY_H
#define __KEY_H

void Key1_Init(void);



#endif

#ifndef function_H
#define function_H

void gogogo(int p11,int p12);
void Elm_Init(void);
void Elm_open(int a);
void take_qi(int b);
void Key_Init(void);
uint8_t Key_GetNum(void);

#endif

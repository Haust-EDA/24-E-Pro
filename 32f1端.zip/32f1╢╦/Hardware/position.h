#ifndef __position_H
#define __position_H


extern int  pxy[20][2];
#endif

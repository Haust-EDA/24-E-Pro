#ifndef __saomiao_H
#define __saomiao_H

void saomiao();
void zhuaqizi(uint32_t num);
void  fuwei(void);
#endif


#ifndef __write_H
#define __write_H


void  x_move(uint32_t dir,uint32_t num,uint32_t speed);
void  y_move(uint32_t dir,uint32_t num,uint32_t speed);
void put_move(uint32_t motor_number);
#endif
